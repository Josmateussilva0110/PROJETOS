from FUNÇÕES.tipos import dados

def linha(tam= 30):
    return '-' * tam


def cabeçalho(txt):
    print(linha())
    print(txt.center(30))
    print(linha())



def menu(lista):
    cabeçalho('MENU PRINCIPAL')
    cont = 1
    print()
    for item in lista:
        print(f'{cont} - {item}')
        cont += 1
    print(linha())
    opc = dados.leia_int('sua opção: ', 0, 6)
    return opc


def mostrar_dados(nome, telefone):
    print(f'nome: {nome} telefone: {telefone}')


def menu_alterar(lista):
    cabeçalho('OPÇÕES')
    cont = 1
    for item in lista:
        print(f'{cont}- {item}')
        cont += 1
    print(linha())
