from FUNÇÕES.tipos.apresentar import *
from os import system

agenda = list()
def cadastrar_nome():
    return(input('nome: '))


def cadastrar_telefone():
    while True:
        try:
            telefone = int(input('telefone: '))
        except (ValueError, TypeError):
           print('ERRO, digite um valor valido')
        except (KeyboardInterrupt):
            print('usuario preferiu não digitar esse número')
        else:
            return telefone


def nome_arquivo():
    return(input('nome do arquivo: '))



def cadastrar_novo():
    global agenda
    nome = cadastrar_nome()
    telefone = cadastrar_telefone()
    agenda.append([nome, telefone])
    print('dados cadastrados.')


def apagar():
    global agenda
    listar()
    nome = cadastrar_nome()
    p = pesquisar(nome)
    if p != None:
        del agenda[p]
        print('dados apagados com sucesso.')
    else:
        print('nome não encontrado')


def alterar():
    listar()
    p = pesquisar(cadastrar_nome())
    if p != None:
        nome = agenda[p][0]
        telefone = agenda[p][1]
        print('encontrado:')
        menu_alterar(['nome','telefone','nome/telefone'])
        op = leia_int('sua opção: ', 1, 3)
        if op == 1:
            nome = cadastrar_nome()
            agenda[p] = [nome, telefone]
            print('dados alterados com sucesso.')
        if op == 2:
            telefone = cadastrar_telefone()
            agenda[p] = [nome, telefone]
            print('dados alterados com sucesso.')
        if op == 3:
            nome = cadastrar_nome()
            telefone = cadastrar_telefone()
            agenda[p] = [nome, telefone]
            print('dados alterados com sucesso.')
    else:
        print('não encontrado.')



def gravar():
    arquivo = nome_arquivo()
    arq = open(arquivo, 'wt')
    for i in agenda:
        arq.write(f'{i[0]}:{i[1]}\n')
    print('arquivo salvo com sucesso.')
    arq.close()



def leia_int(pergunta, inicio = 0, fim = 6):
    while True:
        try:
            valor = int(input(pergunta))
            if inicio <= valor <= fim:
                return valor
            else:
                print(f'valor invalido digite entre {inicio} e {fim}')
        except (ValueError, TypeError):
           print('ERRO, digite um valor valido')
        except (KeyboardInterrupt):
            print('usuario preferiu não digitar esse número')
            return 0


def listar():
    cabeçalho('AGENDA')
    for j, i in enumerate(agenda):
        mostrar_dados(i[0], i[1])
    linha()


def pesquisar(nome):
    mnome = nome.lower()
    for p, e in enumerate(agenda):
        if e[0].lower() == mnome:
            return p
    return None


def escolha(opc):
    if opc == 1:
        cadastrar_novo()
    elif opc == 2:
        alterar()
    elif opc == 3:
        apagar()
    elif opc == 4:
        listar()
    elif opc == 5:
        gravar()
