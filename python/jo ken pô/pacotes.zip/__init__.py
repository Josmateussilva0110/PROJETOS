from time import sleep
def linha():
    return '-='*15


def cabeçalho(txt):
    print(linha())
    print(txt.center(15))
    print(linha())


def menu(lista):
    cabeçalho('\033[1;36;40mSUAS OPÇÕES\033[m')
    cont = 0
    for item in lista:
        print(f'\033[1;36;40m{cont} - {item}\033[m')
        cont += 1
    print(linha())
    while True:
        opc = int(input('sua opção: '))
        if opc <= 2:
            break
        else:
            print('\033[1;31mERRO, digite um valor valida\033[m')
    return opc


def animacao():
    print("\033[1;34mJO\033[m")
    sleep(1)
    print("\033[1;33mKEN\033[m")
    sleep(1)
    print("\033[1;32mPÔ\033[m")
    sleep(1)


def juiz(x, y, nome):
    if x == 0:
        if y == 0:
            print("\033[1;33mEMPATOU\033[m")
        elif y == 1:
            print(f'\033[1;32m JOGADOR(A) {nome} GANHOU :)\033[m')
        elif y == 2:
            print(f'\033[1;31m JOGADOR(A) {nome} PERDEU :<\033[m')
        else:
            print("OPÇÃO IVALIDA")
    elif x == 1:
        if y == 0:
            print(f'\033[1;31m JOGADOR(A) {nome} PERDEU :<\033[m')
        elif y == 1:
            print("\033[1;33mEMPATOU\033[m")
        elif y == 2:
            print(f'\033[1;32m JOGADOR(A) {nome} GANHOU :)\033[m')
        else:
            print("OPÇÃO INVALIDA")
    elif x == 2:
        if y == 0:
            print(f'\033[1;32m JOGADOR(A) {nome} GANHOU :)\033[m')
        elif y == 1:
            print(f'\033[1;31m JOGADOR(A) {nome} PERDEU :<\033[m')
        elif y == 2:
            print("\033[1;33mEMPATOU\033[m")
        else:
            print("OPÇÃO INVALIDA")
