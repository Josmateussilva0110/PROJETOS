def ler_nome(texto):
    while True:
        try:
            nome = input(texto)
            if not nome.isalpha():
                raise ValueError
        except ValueError:
            print('\033[1;31mERRO, digite um valor valida\033[m')
        except KeyboardInterrupt:
            print('Usuario preferiu nao digitar esse nome')
        else:
            return nome


def ler_int(texto, inicio = 1, fim = 2):
    while True:
        try:
            valor = int(input(texto))
            if inicio <= valor <= fim:
                return valor
            else:
                print(f'digite um valor entre {inicio} e {fim}')
        except(ValueError, TypeError):
            print('\033[1;31mERRO, digite um valor valida\033[m')
        except(KeyboardInterrupt):
            print('Usuario preferiu nao digitar esse nome')
